<?php 

// Memanggil file connect.php, gunanya untuk memanggil koneksi database yang sudah kita buat di file connect.php
include"connect.php"; 

// Jika tombol Tambah Data Laporan diklik, maka akan mengirimkan data yang baru saja diinput dan disederhanakan menggunakan variable
if(isset($_POST['addData'])) {
    $kesatuan        = $_POST['kesatuan'];
    $no_laporan      = $_POST['no_laporan'];
    $tgl_laporan     = $_POST['tgl_laporan'];
    $jenis_kejadian  = $_POST['jenis_kejadian'];
    $lokasi          = $_POST['lokasi'];
    $tanggal_kejadia = $_POST['tanggal_kejadian'];
    $modus           = $_POST['modus'];
    $no_polisi       = $_POST['no_polisi'];
    $jenis_kendaraan = $_POST['jenis_kendaraan'];
    $merk_type       = $_POST['merk_type'];
    $tahun_pembuatan = $_POST['tahun_pembuatan'];
    $warna           = $_POST['warna'];
    $no_rangka       = $_POST['no_rangka'];
    $no_mesin        = $_POST['no_mesin'];
    $nama_pelapor    = $_POST['nama_pelapor'];
    $nama_pemilik    = $_POST['nama_pemilik'];
    $alamat_pelapor  = $_POST['alamat_pelapor'];
    $alamat_pemilik  = $_POST['alamat_pemilik'];

    // Melakukan penginputan / penambahan data kedalam table tb_daftar_ranmor
    $inputData = $conn->query("INSERT INTO tb_daftar_ranmor VALUES (NULL, '$kesatuan','$no_laporan','$tgl_laporan','$jenis_kejadian','$lokasi','$tanggal_kejadia','$modus','$no_polisi','$jenis_kendaraan','$merk_type','$tahun_pembuatan','$warna','$no_rangka','$no_mesin','$nama_pelapor','$alamat_pelapor','$nama_pemilik','$alamat_pemilik')");

    // Jika input data berhasil, maka akn muncul pesan "Data Berhasil di input!" menggunakan Alert dari javascript dan selanjutnya akan teralihkan kehalaman index 
    if($inputData) {
        echo "<script>alert('Data Berhasil di input!'); location.href='./';</script>";
    } else {
        die("Connection failed: " . $conn->error); // Jika error, maka akan menampilkan pesan errornya
    }

}

?>