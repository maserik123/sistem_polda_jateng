<?php
// Memanggil file connect.php, gunanya untuk memanggil koneksi database yang sudah kita buat di file connect.php
include"connect.php";

// Jika tombol login diklik, lakukan seleksi data

if(isset($_POST['doLogin'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // Menyeleksi data berdasarkan username
    $searchUser = $conn->query("SELECT * FROM tb_admin WHERE username='$user'");
    $countUser = mysqli_num_rows($searchUser);

    // Jika ada, maka selanjutkanya program akan mengambil Password yang sudah diencrypt pada table tb_admin
    if($countUser == 1) {
        $rowUser = mysqli_fetch_array($searchUser);
        $getPassword = $rowUser['password'];

        // Selanjutnya akan mencocokan password yang dinput dengan password yang sudah di encrypt pada tb_admin. Disini saya menggunakan PASSWORD_HASH untuk encrypt passwordnya
        if(password_verify($pass, $getPassword)) {
            // Jika berhasil langsung mengaktifkan session, lalu terlihkan ke halaman utama.
            session_start();
            $_SESSION['name'] = $rowUser['nama'];
            header('location: ./');
        } else {
            // Jika password tidak cocok, Maka akan menampilkan pesan seperti ini 
            echo "<script>alert('Username / Password Salah!'); location.href='./login.php';</script>";
        }
    } else {
        // Jika username tidak cocok, Maka akan menampilkan pesan seperti ini 
        echo "<script>alert('Username / Password Salah!'); location.href='./login.php';</script>";
    }
}

?>