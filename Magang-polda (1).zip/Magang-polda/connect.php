<?php 

// Dibawah ini kode untuk menghubungkan database dengan websitenya

$dbhost = "localhost"; // Nama Server, Biasanya semua server menggunakan localhost
$dbuser = "root"; // User yang terkoneksi dengan database, Biasanya "root" jika menggunakan xampp. Berbeda jika menggunakan hosting
$dbpass = ""; // Password user, Biasanya Kosong. Berbeda jika menggunakan hosting
$dbname = "db_polda_jateng"; // Nama Database

$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname); // Kode untuk mengkoneksikan database dengan websitenya menggunakan data diatas 

// Kode dibawah ini berguna jika koneksi gagal, maka akan muncul pesan errornya
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

?>