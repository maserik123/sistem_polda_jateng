-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2020 at 10:23 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_polda_jateng`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id_admin` int(1) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id_admin`, `nama`, `username`, `password`) VALUES
(1, 'Ali Gaga', 'admin', '$2y$10$ujMKMV18M5mYoRratkJ4Neg3zebsSN2XwL3dYWRlHYzC4/rB0cH2e');

-- --------------------------------------------------------

--
-- Table structure for table `tb_daftar_ranmor`
--

CREATE TABLE `tb_daftar_ranmor` (
  `id_laporan` int(3) NOT NULL,
  `kesatuan` varchar(50) NOT NULL,
  `no_laporan` varchar(50) NOT NULL,
  `tgl_laporan` date NOT NULL,
  `jenis_kejadian` varchar(50) NOT NULL,
  `lokasi` varchar(50) NOT NULL,
  `tgl_kejadian` date NOT NULL,
  `modus` varchar(30) NOT NULL,
  `no_polisi` varchar(15) NOT NULL,
  `jenis_kendaraan` varchar(10) NOT NULL,
  `merk_type` varchar(30) NOT NULL,
  `tahun_pembuatan` int(4) DEFAULT NULL,
  `warna` varchar(20) NOT NULL,
  `no_rangka` varchar(50) NOT NULL,
  `no_mesin` varchar(50) NOT NULL,
  `nama_pelapor` varchar(50) DEFAULT NULL,
  `alamat_pelapor` text DEFAULT NULL,
  `nama_pemilik` varchar(50) DEFAULT NULL,
  `alamat_pemilik` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_daftar_ranmor`
--

INSERT INTO `tb_daftar_ranmor` (`id_laporan`, `kesatuan`, `no_laporan`, `tgl_laporan`, `jenis_kejadian`, `lokasi`, `tgl_kejadian`, `modus`, `no_polisi`, `jenis_kendaraan`, `merk_type`, `tahun_pembuatan`, `warna`, `no_rangka`, `no_mesin`, `nama_pelapor`, `alamat_pelapor`, `nama_pemilik`, `alamat_pemilik`) VALUES
(1, 'POLRES KLATEN', 'LP/B/18/VII/2020/JATENG/RES.KLATEN', '2020-08-01', 'Hilang', 'Rumah', '2020-08-01', 'Penggelapan', 'AD-2891-DKC', 'SPM', 'Honda Genio', NULL, 'Merah Hitam', 'MH1JM6110KKO48439', 'JM61E1048119', 'Indraswati', NULL, NULL, NULL),
(2, 'POLRES SUKOHARJO', 'LP / B / 103 / VIII / 2020 / JATENG /RES.SK', '2020-08-05', 'Hilang', 'Jalan', '2020-08-05', 'Penggelapan', 'AD-9115-YC', 'Mobil', 'Toyota Avanza', 2014, 'Hitam', 'MHKM1BA2JEK059679', 'ME48046', 'PT. BFI FINANCE SOLO BARU', '', '', ''),
(3, 'POLRES SEMARANG', 'LP / 21 / VIII / 2020 /JATENG / RES SMG', '2020-08-07', 'Hilang', 'Teras Rumah', '2020-08-07', 'Currat', 'H-5476-AWC', 'SPM', 'Honda Beat', 2019, 'Putih', 'MH1JFZ130KK631932', 'JFZ1E3633178', 'Mohtar Wibowo', '', '', ''),
(4, 'POLRESTA MAGELANG', 'LP/B//62/VIII/2020/JATENG/RES MGL KT', '2020-08-08', 'Hilang', 'Masjid', '2020-08-08', 'Curi R2', 'AA-6765-IG', 'SPM', 'Honda Genio', 2019, 'Putih Biru', 'MH1JM7111KK094786', 'M71E1094788', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `tb_daftar_ranmor`
--
ALTER TABLE `tb_daftar_ranmor`
  ADD PRIMARY KEY (`id_laporan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id_admin` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_daftar_ranmor`
--
ALTER TABLE `tb_daftar_ranmor`
  MODIFY `id_laporan` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
