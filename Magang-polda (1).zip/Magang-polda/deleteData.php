<?php 

// Memanggil file connect.php, gunanya untuk memanggil koneksi database yang sudah kita buat di file connect.php
include"connect.php"; 

// Menangkap id laporan
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    // Melakukan penghapusan laporan berdasarkan ID yang ditangkap
    $deleteData = $conn->query("DELETE FROM tb_daftar_ranmor WHERE id_laporan='$id'");

    // Jika hapus data berhasil, maka akn muncul pesan "Data Berhasil di hapus!" menggunakan Alert dari javascript dan selanjutnya akan teralihkan kehalaman index 
    if($deleteData) {
        echo "<script>alert('Data Berhasil di hapus!'); location.href='./';</script>";
    } else {
        die("Connection failed: " . $conn->error); // Jika error, maka akan menampilkan pesan errornya
    }
}

?>