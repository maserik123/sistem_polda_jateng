<?php 

// Memanggil file connect.php, gunanya untuk memanggil koneksi database yang sudah kita buat di file connect.php
include"connect.php"; 

// Jika tombol editData Laporan diklik, maka akan mengirimkan data yang baru saja diinput dan disederhanakan menggunakan variable
if(isset($_POST['editData'])) {
    $idLaporan       = $_POST['setIdLaporan'];
    $kesatuan        = $_POST['kesatuan'];
    $no_laporan      = $_POST['no_laporan'];
    $tgl_laporan     = $_POST['tgl_laporan'];
    $jenis_kejadian  = $_POST['jenis_kejadian'];
    $lokasi          = $_POST['lokasi'];
    $tanggal_kejadia = $_POST['tanggal_kejadian'];
    $modus           = $_POST['modus'];
    $no_polisi       = $_POST['no_polisi'];
    $jenis_kendaraan = $_POST['jenis_kendaraan'];
    $merk_type       = $_POST['merk_type'];
    $tahun_pembuatan = $_POST['tahun_pembuatan'];
    $warna           = $_POST['warna'];
    $no_rangka       = $_POST['no_rangka'];
    $no_mesin        = $_POST['no_mesin'];
    $nama_pelapor    = $_POST['nama_pelapor'];
    $nama_pemilik    = $_POST['nama_pemilik'];
    $alamat_pelapor  = $_POST['alamat_pelapor'];
    $alamat_pemilik  = $_POST['alamat_pemilik'];

    // Melakukan perubahan data berdasarkan id laporan yang dituju
    $updateData = $conn->query("UPDATE tb_daftar_ranmor SET kesatuan='$kesatuan', no_laporan='$no_laporan', tgl_laporan='$tgl_laporan', jenis_kejadian='$jenis_kejadian', lokasi='$lokasi', tgl_kejadian='$tanggal_kejadia', modus='$modus', no_polisi='$no_polisi', jenis_kendaraan='$jenis_kendaraan', merk_type='$merk_type', tahun_pembuatan='$tahun_pembuatan', warna='$warna', no_rangka='$no_rangka', no_mesin='$no_mesin', nama_pelapor='$nama_pelapor', alamat_pelapor='$alamat_pelapor', nama_pemilik='$nama_pemilik', alamat_pemilik='$alamat_pemilik' WHERE id_laporan='$idLaporan'");

    // Jika update data berhasil, maka akn muncul pesan "Data Berhasil di update!" menggunakan Alert dari javascript dan selanjutnya akan teralihkan kehalaman index 
    if($updateData) {
        echo "<script>alert('Data Berhasil di update!'); location.href='./';</script>";
    } else {
        die("Connection failed: " . $conn->error); // Jika error, maka akan menampilkan pesan errornya
    }

}

?>