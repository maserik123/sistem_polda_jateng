<?php 

// Memanggil file connect.php, gunanya untuk memanggil koneksi database yang sudah kita buat di file connect.php
include"connect.php"; 

// Jika tombol Edit Laporan diklik, maka akan mengirimkan data yang baru saja diinput dan disederhanakan menggunakan variable
if(isset($_POST['idLaporan'])) {
    $idLaporan  = $_POST['idLaporan'];

    // Melakukan pemilihan data berdasarkan id laporannya
    $showData = $conn->query("SELECT * FROM tb_daftar_ranmor WHERE id_laporan='$idLaporan'");
    
    // Menampilkan data yang terpilih dalam bentuk JSON agar mudah diextract di form editnya
    echo json_encode(mysqli_fetch_assoc($showData));

}

?>