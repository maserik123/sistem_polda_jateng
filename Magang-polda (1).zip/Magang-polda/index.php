<?php 
session_start(); // Memulai Session

// Jika anda belum login maka akan teralihkan ke halaman login :)
if(!isset($_SESSION['name'])) {
    header('location: login.php');
}

// Memanggil file connect.php, gunanya untuk memanggil koneksi database yang sudah kita buat di file connect.php
include"connect.php"; 

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>KEPOLISIAN NEGARA REPUBLIK INDONESIA</title>
  <link rel="stylesheet" href="static/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="static/vendors/base/vendor.bundle.base.css">
  <link rel="stylesheet" href="static/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
  <link rel="stylesheet" href="static/css/style.css">
  <style>
      .form-control {
          border: 1px solid rgba(0,0,0, 0.1);
      }
  </style>
</head>
<body>
  <div class="container-scroller">
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex justify-content-center">
        <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">  
          <a class="navbar-brand brand-logo" href="./">Polda Jateng</a>
          <a class="navbar-brand brand-logo-mini" href="./">PJ</a>
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-sort-variant"></span>
          </button>
        </div>  
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
              <img src="static/images/profile.png" alt="profile"/>
              <span class="nav-profile-name"><?= $_SESSION['name'] ?></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
            <a class="dropdown-item" href="password.php">
                <i class="mdi mdi-lock text-primary"></i>
                Ubah Password
              </a>
              <a class="dropdown-item" href="logout.php">
                <i class="mdi mdi-logout text-primary"></i>
                Keluar
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>
    <div class="container-fluid page-body-wrapper">
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="./">
              <i class="mdi mdi-home menu-icon"></i>
              <span class="menu-title">Halaman Utama</span>
            </a>
          </li>
        </ul>
      </nav>
      <div class="main-panel">
        <div class="content-wrapper">
          
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between flex-wrap">
                <div class="d-flex align-items-end flex-wrap">
                  <div class="mr-md-3 mr-xl-5">
                    <?php 
                      // Membuat query untuk memanggil nama pada table "tb_admin"
                      $queryNama = $conn->query("SELECT * FROM tb_admin");
                      $rowQueryNama = mysqli_fetch_array($queryNama);

                      $setFullName = $rowQueryNama['nama']; // Mengambil Nama
                    ?>
                    <h2>Selamat Datang Kembali, <?= $setFullName ?> <!-- Kode disamping kiri ini untuk memanggil nama berdasarkan username log --></h2>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title">Daftar Ranmor Hilang Polda Jateng</p>
                    <div class="row">
                      <div class="col-md-2 col-12"><button class="btn btn-primary mb-3" data-toggle="modal" data-target="#tambahData">Tambah Laporan</button></div>
                    </div>
					
                  <div class="table-responsive">
                    <table id="recent-purchases-listing" class="table">
                      <thead>
                        <tr>
                            <th>
                                <div class="mb-2 d-block">Kesatuan</div>
                                <div class="mb-2 d-block">No. Laporan</div>
                                <div class="d-block">Tanggal Laporan</div>
                                <div class="d-block">&nbsp;</div>
                            </th>
                            <th>
                                <div class="mb-2 d-block">Jenis Kejadian</div>
                                <div class="mb-2 d-block">Lokasi</div>
                                <div class="mb-2 d-block">Tanggal Kejadian</div>
                                <div class="d-block">Modus</div>
                            </th>
                            <th>
                                <div class="mb-2 d-block">No. Polisi</div>
                                <div class="mb-2 d-block">Jenis Kendaraan</div>
                                <div class="mb-2 d-block">Merk / Type</div>
                                <div class="d-block">Tahun Pembuatan</div>
                            </th>
                            <th>
                                <div class="mb-2 d-block">Warna</div>
                                <div class="mb-2 d-block">No. Rangka</div>
                                <div class="mb-2 d-block">No. Mesin</div>
                                <div class="d-block">&nbsp;</div>
                            </th>
                            <th>
                                <div class="mb-2 d-block">Nama Pelapor</div>
                                <div class="mb-2 d-block">Alamat Pelapor</div>
                                <div class="mb-2 d-block">Nama Pemilik</div>
                                <div class="d-block">Alamat Pemilik</div>
                            </th>
                            <th>
                                <div class="mb-2 d-block">Aksi</div>
                            </th>
                        </tr>
                      </thead>
                      <tbody>
                          <!-- Membuka tag PHP untuk memulai program -->
                          <?php 
                            // Membuat query untuk memanggil nama table laporan

                            // $conn adalah koneksi yang kita buat difile connect.php. SELECT * FROM tb_daftar_ranmor artinya kita akan menampilkan semua data yang berada pada table tb_daftar_ranmor
                            $query = $conn->query("SELECT * FROM tb_daftar_ranmor");

                            // Kita akan melakukan perulangan dalam pemanggilan query, agar semua data yang ada pada table bisa terpanggil
                            // Kita memanggil data tersebut menggunakan fungsi mysqli_fetch_array yang artinya kita akan menampilkan data berupa array
                            while($rowQuery = mysqli_fetch_array($query)) { ?>
                            <tr>
                                <td>
                                    <div class="mb-2 d-block"><?= $rowQuery['kesatuan'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom Kesatuan -->
                                    <div class="mb-2 d-block"><?= $rowQuery['no_laporan'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom no_laporan -->
                                    <div class="mb-2 d-block"><?= $rowQuery['tgl_laporan'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom tgl_laporan -->
                                    <div class="d-block">&nbsp;</div> <!-- Disini kosong lalu kenapa kita isi? karena untuk meratakan isi dari table pada website-->
                                </td>
                                <td>
                                    <div class="mb-2 d-block"><?= $rowQuery['jenis_kejadian'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom jenis_kejadian -->
                                    <div class="mb-2 d-block"><?= $rowQuery['lokasi'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom lokasi -->
                                    <div class="mb-2 d-block"><?= $rowQuery['tgl_kejadian'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom tgl_kejadian -->
                                    <div class="d-block"><?= $rowQuery['modus'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom modus -->
                                </td>
                                <td>
                                    <div class="mb-2 d-block"><?= $rowQuery['no_polisi'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom no_polisi -->
                                    <div class="mb-2 d-block"><?= $rowQuery['jenis_kendaraan'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom jenis_kendaraan -->
                                    <div class="mb-2 d-block"><?= $rowQuery['merk_type'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom merk_type -->
                                    <div class="d-block"><?= $rowQuery['tahun_pembuatan'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom tahun_pembuatan -->
                                </td>
                                <td>
                                    <div class="mb-2 d-block"><?= $rowQuery['warna'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom warna -->
                                    <div class="mb-2 d-block"><?= $rowQuery['no_rangka'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom no_rangka -->
                                    <div class="mb-2 d-block"><?= $rowQuery['no_mesin'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom no_mesin -->
                                    <div class="d-block">&nbsp;</div> <!-- Disini kosong lalu kenapa kita isi? karena untuk meratakan isi dari table pada website-->
                                </td>
                                <td>
                                    <div class="mb-2 d-block"><?= $rowQuery['nama_pelapor'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom nama_pelapor -->
                                    <div class="mb-2 d-block"><?= $rowQuery['alamat_pelapor'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom alamat_pelapor -->
                                    <div class="mb-2 d-block"><?= $rowQuery['nama_pemilik'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom nama_pemilik -->
                                    <div class="d-block"><?= $rowQuery['alamat_pemilik'] ?></div> <!-- Memanggil dan menampilkan isi dari kolom alamat_pemilik -->
                                </td>
                                <td>
                                    <div class="mb-2 d-block"><button class="btn btn-info p-2" data-id="<?= $rowQuery['id_laporan'] ?>" id="editDataModal" data-toggle="modal" data-target="#editData">Edit Data</button></div>
                                    <div class="mb-2 d-block"><a class="btn btn-danger p-2" onclick="return confirm('Anda yakin ingin menghapus data ini?');" href="deleteData.php?id=<?= $rowQuery['id_laporan'] ?>">Hapus Data</a></div>
                                </td>
                            </tr>
                            <?php }
                          ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2020 Polda Jateng. All rights reserved.</span>
          </div>
        </footer>
      </div>
    </div>
  </div>

  <!-- Form untuk menmabahkan data -->
    <div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Data Laporan</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="addData.php" method="POST">
            <div class="modal-body">
                <div class="form-group row">
                    <div class="col-md-4 col-12">
                        <label for="">Kesatuan <span class="text-danger">*</span></label>
                        <input type="text" name="kesatuan" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">No. Laporan <span class="text-danger">*</span></label>
                        <input type="text" name="no_laporan" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Tanggal Laporan <span class="text-danger">*</span></label>
                        <input type="date" name="tgl_laporan" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4 col-12">
                        <label for="">Jenis Kejadian <span class="text-danger">*</span></label>
                        <input type="text" name="jenis_kejadian" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Lokasi <span class="text-danger">*</span></label>
                        <input type="text" name="lokasi" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Tanggal Kejadian <span class="text-danger">*</span></label>
                        <input type="date" name="tanggal_kejadian" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4 col-12">
                        <label for="">Modus <span class="text-danger">*</span></label>
                        <input type="text" name="modus" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">No. Polisi <span class="text-danger">*</span></label>
                        <input type="text" name="no_polisi" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Jenis Kendaraan <span class="text-danger">*</span></label>
                        <input type="text" name="jenis_kendaraan" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4 col-12">
                        <label for="">Merk / Type <span class="text-danger">*</span></label>
                        <input type="text" name="merk_type" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Tahun Pembuatan</label>
                        <input type="text" name="tahun_pembuatan" class="form-control">
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Warna <span class="text-danger">*</span></label>
                        <input type="text" name="warna" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4 col-12">
                        <label for="">No. Rangka <span class="text-danger">*</span></label>
                        <input type="text" name="no_rangka" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">No. Mesin <span class="text-danger">*</span></label>
                        <input type="text" name="no_mesin" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Nama Pelapor</label>
                        <input type="text" name="nama_pelapor" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    
                    <div class="col-md-4 col-12">
                        <label for="">Nama Pemilik</label>
                        <input type="text" name="nama_pemilik" class="form-control">
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Alamat Pelapor</label>
                        <textarea name="alamat_pelapor" class="form-control"></textarea>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Alamat Pemilik</label>
                        <textarea name="alamat_pemilik" class="form-control"></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" name="addData" class="btn btn-primary">Tambah Laporan</button>
            </div>
        </form>
        </div>
    </div>
    </div>

    <!-- Form untuk mengubah data -->
    <div class="modal fade" id="editData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit Data Laporan</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="editData.php" method="POST">
            <input type="hidden" name="setIdLaporan" id="setIdLaporan">
            <div class="modal-body">
                <div class="form-group row">
                    <div class="col-md-4 col-12">
                        <label for="">Kesatuan <span class="text-danger">*</span></label>
                        <input type="text" name="kesatuan" id="kesatuan" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">No. Laporan <span class="text-danger">*</span></label>
                        <input type="text" name="no_laporan" id="no_laporan" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Tanggal Laporan <span class="text-danger">*</span></label>
                        <input type="date" name="tgl_laporan" id="tgl_laporan" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4 col-12">
                        <label for="">Jenis Kejadian <span class="text-danger">*</span></label>
                        <input type="text" name="jenis_kejadian" id="jenis_kejadian" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Lokasi <span class="text-danger">*</span></label>
                        <input type="text" name="lokasi" id="lokasi" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Tanggal Kejadian <span class="text-danger">*</span></label>
                        <input type="date" name="tanggal_kejadian" id="tanggal_kejadian" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4 col-12">
                        <label for="">Modus <span class="text-danger">*</span></label>
                        <input type="text" name="modus" id="modus" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">No. Polisi <span class="text-danger">*</span></label>
                        <input type="text" name="no_polisi" id="no_polisi" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Jenis Kendaraan <span class="text-danger">*</span></label>
                        <input type="text" name="jenis_kendaraan" id="jenis_kendaraan" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4 col-12">
                        <label for="">Merk / Type <span class="text-danger">*</span></label>
                        <input type="text" name="merk_type" id="merk_type" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Tahun Pembuatan</label>
                        <input type="text" name="tahun_pembuatan" id="tahun_pembuatan" class="form-control">
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Warna <span class="text-danger">*</span></label>
                        <input type="text" name="warna" id="warna" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4 col-12">
                        <label for="">No. Rangka <span class="text-danger">*</span></label>
                        <input type="text" name="no_rangka" id="no_rangka" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">No. Mesin <span class="text-danger">*</span></label>
                        <input type="text" name="no_mesin" id="no_mesin" class="form-control" required>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Nama Pelapor</label>
                        <input type="text" name="nama_pelapor" id="nama_pelapor" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    
                    <div class="col-md-4 col-12">
                        <label for="">Nama Pemilik</label>
                        <input type="text" name="nama_pemilik" id="nama_pemilik" class="form-control">
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Alamat Pelapor</label>
                        <textarea name="alamat_pelapor" id="alamat_pelapor" class="form-control"></textarea>
                    </div>
                    <div class="col-md-4 col-12">
                        <label for="">Alamat Pemilik</label>
                        <textarea name="alamat_pemilik" id="alamat_pemilik" class="form-control"></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" name="editData" class="btn btn-primary">Edit Laporan</button>
            </div>
        </form>
        </div>
    </div>
    </div>

  <script src="static/vendors/base/vendor.bundle.base.js"></script>
  <script src="static/vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="static/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <script src="static/js/template.js"></script>
  <script src="static/js/dashboard.js"></script>
  <script src="static/js/data-table.js"></script>
  <script src="static/js/jquery.dataTables.js"></script>
  <script src="static/js/dataTables.bootstrap4.js"></script>

  <script>
      $(document).ready(function() {
        $("button#editDataModal").on('click', function() {
            var idLaporan = $(this).attr("data-id");

            $.ajax({
                url: "getData.php",
                type: "POST",
                data: "idLaporan="+idLaporan,
                dataType: "json",
                success: function(response) {
                    $("#setIdLaporan").val(response.id_laporan);
                    $("#kesatuan").val(response.kesatuan);
                    $("#no_laporan").val(response.no_laporan);
                    $("#tgl_laporan").val(response.tgl_laporan);
                    $("#jenis_kejadian").val(response.jenis_kejadian);
                    $("#lokasi").val(response.lokasi);
                    $("#tanggal_kejadian").val(response.tanggal_kejadian);
                    $("#modus").val(response.modus);
                    $("#no_polisi").val(response.no_polisi);
                    $("#jenis_kendaraan").val(response.jenis_kendaraan);
                    $("#merk_type").val(response.merk_type);
                    $("#tahun_pembuatan").val(response.tahun_pembuatan);
                    $("#warna").val(response.warna);
                    $("#no_rangka").val(response.no_rangka);
                    $("#no_mesin").val(response.no_mesin);
                    $("#nama_pelapor").val(response.nama_pelapor);
                    $("#nama_pemilik").val(response.nama_pemilik);
                    $("#alamat_pelapor").val(response.alamat_pelapor);
                    $("#alamat_pemilik").val(response.alamat_pemilik);
                }
            });
        });
      });
  </script>
</body>

</html>

