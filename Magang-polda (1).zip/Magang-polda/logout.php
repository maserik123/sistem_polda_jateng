<?php 
// Jika Logout terklik maka session akan dihentikan lalu mengalihkan ke halaman login kembali
session_start();
session_destroy();

header('location: ./login.php');

?>