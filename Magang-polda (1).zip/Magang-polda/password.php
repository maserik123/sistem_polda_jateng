<?php 
session_start(); // Memulai Session

// Jika anda belum login maka akan teralihkan ke halaman login :)
if(!isset($_SESSION['name'])) {
    header('location: login.php');
}

// Memanggil file connect.php, gunanya untuk memanggil koneksi database yang sudah kita buat di file connect.php
include"connect.php"; 

// Membuat query untuk memanggil username pada table "tb_admin"
$query = $conn->query("SELECT * FROM tb_admin");
$rowQuery = mysqli_fetch_array($query);

$setUsername = $rowQuery['username']; // Mengambil Username
$setFullName = $rowQuery['nama']; // Mengambil Nama

// Program untuk mengubah password

if(isset($_POST['doChangePassword'])) {
  $getUser = $_POST['user']; // Mengambil username dari form
  $getName = $_POST['fullName']; // Mengambil nama lengkap dari form
  $getPass = $_POST['newPass']; // Mengambil password baru dari form

  $hashNewPass = password_hash($getPass, PASSWORD_BCRYPT); // Encrypt password baru menggunakan password_hash

  // Melakukan query update password
  $queryUbahPass = $conn->query("UPDATE tb_admin SET nama='$getName', password='$hashNewPass' WHERE username='$getUser'");
  if($queryUbahPass) {
    echo "<script>alert('Password berhasil diubah!'); location.href='./';</script>";
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>KEPOLISIAN NEGARA REPUBLIK INDONESIA</title>
  <link rel="stylesheet" href="static/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="static/vendors/base/vendor.bundle.base.css">
  <link rel="stylesheet" href="static/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
  <link rel="stylesheet" href="static/css/style.css">
  <style>
      .form-control {
          border: 1px solid rgba(0,0,0, 0.1);
      }
  </style>
</head>
<body>
  <div class="container-scroller">
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex justify-content-center">
        <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">  
          <a class="navbar-brand brand-logo" href="./">Polda Jateng</a>
          <a class="navbar-brand brand-logo-mini" href="./">PJ</a>
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-sort-variant"></span>
          </button>
        </div>  
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
              <img src="static/images/profile.png" alt="profile"/>
              <span class="nav-profile-name"><?= $_SESSION['name'] ?></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
            <a class="dropdown-item" href="password.php">
                <i class="mdi mdi-lock text-primary"></i>
                Ubah Password
              </a>
              <a class="dropdown-item" href="logout.php">
                <i class="mdi mdi-logout text-primary"></i>
                Keluar
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>
    <div class="container-fluid page-body-wrapper">
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="./">
              <i class="mdi mdi-home menu-icon"></i>
              <span class="menu-title">Halaman Utama</span>
            </a>
          </li>
        </ul>
      </nav>
      <div class="main-panel">
        <div class="content-wrapper">
          
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between flex-wrap">
                <div class="d-flex align-items-end flex-wrap">
                  <div class="mr-md-3 mr-xl-5">
                    <h2>Selamat Datang Kembali, <?= $setFullName ?> <!-- Kode disamping kiri ini untuk memanggil nama berdasarkan username log --></h2>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 stretch-card">
            <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Ubah Password</h4>
                  <form class="forms-sample" action="<?= $_SERVER['PHP_SELF'] ?>" method="POST">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Nama Pengguna</label>
                      <input type="text" class="form-control" name="user" value="<?= $setUsername ?>" readonly>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Nama Lengkap</label>
                      <input type="text" class="form-control" name="fullName" value="<?= $setFullName ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Kata Sandi Baru</label>
                      <input type="password" class="form-control" name='newPass' placeholder="New Password">
                    </div>
                    <button type="submit" class="btn btn-primary mr-2" name="doChangePassword">Ubah Password</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2020 Polda Jateng. All rights reserved.</span>
          </div>
        </footer>
      </div>
    </div>
  </div>

  <script src="static/vendors/base/vendor.bundle.base.js"></script>
  <script src="static/vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="static/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <script src="static/js/template.js"></script>
  <script src="static/js/dashboard.js"></script>
  <script src="static/js/data-table.js"></script>
  <script src="static/js/jquery.dataTables.js"></script>
  <script src="static/js/dataTables.bootstrap4.js"></script>
</body>

</html>

